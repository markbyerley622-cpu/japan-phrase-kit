# Japan Phrase Kit Seed File

Created: 2026-06-23

This folder contains seed phrase data for an offline Japanese phrasebook/PWA.

Files:
- `japan_phrase_kit_seed.json` — best file for Claude/app import.
- `japan_phrase_kit_seed.csv` — easiest file to edit in Excel/Google Sheets.
- This README.

Structure:
- Personal section: travel, conversation repair, flow, directions, restaurant, hotel, emergency, family/friends.
- Business section: work intro, Combat Reviews, Noise, coding, SaaS, startup/product, customer discovery.

Phrase count: 153

Display order inside the app:
1. English meaning
2. Hiragana
3. Romaji pronunciation
4. Kanji
5. Notes

Recommended next step:
Ask Claude Terminal to create the offline app and import `japan_phrase_kit_seed.json` as the default preloaded phrase dataset.
